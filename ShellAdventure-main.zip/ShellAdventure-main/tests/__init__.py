"""
The docker_tests subpackage runs inside the Docker container.
The tests outside the docker_tests package run outside the Docker container and test the host_side and shared packages
"""
