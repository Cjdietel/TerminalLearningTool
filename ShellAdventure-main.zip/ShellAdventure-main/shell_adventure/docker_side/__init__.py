"""
This package runs the docker-side portion of the tutorial
"""
from pathlib import Path
PKG_PATH = Path(__path__[0]).resolve() # type: ignore  # mypy issue #1422
