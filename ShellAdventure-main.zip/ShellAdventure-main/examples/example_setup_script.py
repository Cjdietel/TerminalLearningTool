from shell_adventure.api import *

# You can create files, run commands or anything else you can do in puzzle generation in a setup script
File("README").create(content = "Welcome to this Linux tutorial")
